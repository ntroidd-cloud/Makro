package com.makro.tiklayici

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** pos: [yatay tuş x,y, yatay hedef x,y, dikey tuş x,y, dikey hedef x,y] — ekranın oranı (0..1), merkez noktası */
class Macro(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "Makro",
    var cps: Int = 12,
    var triggerDp: Float = 72f,
    var targetDp: Float = 96f,
    var toggleMode: Boolean = false,
    var enabled: Boolean = true,
    var opacity: Float = 0.7f,
    var pos: FloatArray = floatArrayOf(0.92f, 0.3f, 0.78f, 0.3f, 0.88f, 0.3f, 0.55f, 0.3f),
    var pkg: String = "", // boşsa her uygulamada, doluysa sadece o uygulama açıkken görünür
    var mode: Int = 0,      // 0 = tıklama, 1 = basılı tut, 2 = kaydır
    var swipeDir: Int = 0,  // 0 yukarı, 1 aşağı, 2 sol, 3 sağ
    var burstSec: Int = 0,  // kaç saniye çalışsın (0 = ara vermeden)
    var pauseSec: Int = 2   // sonra kaç saniye beklesin
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("cps", cps)
        put("triggerDp", triggerDp.toDouble()); put("targetDp", targetDp.toDouble())
        put("pkg", pkg); put("mode", mode); put("swipeDir", swipeDir)
        put("burstSec", burstSec); put("pauseSec", pauseSec); put("toggle", toggleMode); put("enabled", enabled); put("opacity", opacity.toDouble())
        put("pos", JSONArray().also { a -> pos.forEach { a.put(it.toDouble()) } })
    }

    companion object {
        fun fromJson(o: JSONObject): Macro {
            val a = o.getJSONArray("pos")
            return Macro(
                o.getString("id"), o.getString("name"), o.getInt("cps"),
                o.getDouble("triggerDp").toFloat(), o.getDouble("targetDp").toFloat(),
                o.getBoolean("toggle"), o.getBoolean("enabled"), o.getDouble("opacity").toFloat(),
                FloatArray(8) { a.getDouble(it).toFloat() },
                o.optString("pkg", ""),
                o.optInt("mode", 0), o.optInt("swipeDir", 0),
                o.optInt("burstSec", 0), o.optInt("pauseSec", 2)
            )
        }

        fun create(n: Int, pkg: String = ""): Macro {
            val y = 0.25f + 0.17f * (n % 4)
            return Macro(name = "Makro ${n + 1}", pos = floatArrayOf(0.92f, y, 0.78f, y, 0.88f, y, 0.55f, y), pkg = pkg)
        }
    }
}

object Store {
    private fun p(c: Context) = c.getSharedPreferences("macro", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Macro> {
        val s = p(c).getString("list", null) ?: return mutableListOf()
        return try {
            val a = JSONArray(s)
            MutableList(a.length()) { Macro.fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(c: Context, list: List<Macro>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        p(c).edit().putString("list", a.toString()).apply()
    }

    fun getStr(c: Context, k: String, def: String) = p(c).getString(k, def) ?: def
    fun setStr(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
    fun getF(c: Context, k: String, def: Float) = p(c).getFloat(k, def)
    fun setF(c: Context, k: String, v: Float) = p(c).edit().putFloat(k, v).apply()
    fun getBool(c: Context, k: String, def: Boolean) = p(c).getBoolean(k, def)
    fun setBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
}
