package com.makro.tiklayici

import android.content.Context
import android.graphics.*
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max

/** Tuş ve hedef halka için ortak dokunma mantığı. Normal modda bas/bırak, düzenlemede sürükle + iki parmak ölçek. */
open class BaseView(c: Context) : View(c) {
    var edit = false
    var onPress: (() -> Unit)? = null
    var onRelease: (() -> Unit)? = null
    var onSelect: (() -> Unit)? = null
    var onMove: ((Float, Float) -> Unit)? = null
    var onScale: ((Float) -> Unit)? = null
    var onEnd: (() -> Unit)? = null
    private var lx = 0f
    private var ly = 0f
    private var lastDist = 0f

    private fun dist(e: MotionEvent) = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!edit) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> onPress?.invoke()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onRelease?.invoke()
            }
            return true
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { onSelect?.invoke(); lx = e.rawX; ly = e.rawY; lastDist = 0f }
            MotionEvent.ACTION_POINTER_DOWN -> if (e.pointerCount == 2) lastDist = dist(e)
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount >= 2) {
                    val d = dist(e)
                    if (lastDist > 0f && d > 0f) onScale?.invoke(d / lastDist)
                    lastDist = d
                } else {
                    onMove?.invoke(e.rawX - lx, e.rawY - ly)
                    lx = e.rawX; ly = e.rawY
                }
            }
            MotionEvent.ACTION_POINTER_UP -> { lastDist = 0f; lx = e.rawX; ly = e.rawY }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onEnd?.invoke()
        }
        return true
    }
}

/** Oyun içi şeffaf tıklama tuşu (videodaki gibi yuvarlak köşeli yarı saydam kare). */
class TriggerView(c: Context) : BaseView(c) {
    var label = ""
    var active = false
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val r = w * 0.2f
        fill.color = when {
            active -> Color.argb(170, 34, 197, 94)
            edit -> Color.argb(170, 245, 158, 11)
            else -> Color.argb(130, 120, 120, 130)
        }
        val rect = RectF(3f, 3f, w - 3f, w - 3f)
        cv.drawRoundRect(rect, r, r, fill)
        stroke.color = Color.argb(235, 255, 255, 255)
        stroke.strokeWidth = max(2f, w * 0.035f)
        cv.drawRoundRect(rect, r, r, stroke)
        // nişangâh simgesi
        val cx = w / 2f; val cy = w * 0.38f; val ir = w * 0.15f
        stroke.strokeWidth = max(2f, w * 0.04f)
        cv.drawCircle(cx, cy, ir, stroke)
        cv.drawLine(cx, cy - ir * 1.6f, cx, cy - ir * 0.6f, stroke)
        cv.drawLine(cx, cy + ir * 0.6f, cx, cy + ir * 1.6f, stroke)
        cv.drawLine(cx - ir * 1.6f, cy, cx - ir * 0.6f, cy, stroke)
        cv.drawLine(cx + ir * 0.6f, cy, cx + ir * 1.6f, cy, stroke)
        fill.color = Color.WHITE
        cv.drawCircle(cx, cy, ir * 0.25f, fill)
        txt.color = Color.WHITE
        txt.textSize = w * 0.15f
        val s = TextUtils.ellipsize(label, txt, w * 0.82f, TextUtils.TruncateAt.END).toString()
        cv.drawText(s, cx, w * 0.84f, txt)
    }
}

/** Hedef alan: tıklamaların atılacağı kesikli halka. */
class RingView(c: Context) : BaseView(c) {
    var number = 1
    var cpsText = ""
    private var flash = false
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val clear = Runnable { flash = false; invalidate() }

    fun pulse() { flash = true; invalidate(); removeCallbacks(clear); postDelayed(clear, 40) }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val r = w / 2f - 4f
        fill.color = if (edit) Color.argb(70, 34, 211, 238) else Color.argb(if (flash) 90 else 30, 255, 255, 255)
        cv.drawCircle(cx, cx, r, fill)
        stroke.color = if (edit) Color.rgb(34, 211, 238) else Color.argb(220, 255, 255, 255)
        stroke.strokeWidth = max(2f, w * 0.018f)
        stroke.pathEffect = DashPathEffect(floatArrayOf(w * 0.05f, w * 0.045f), 0f)
        cv.drawCircle(cx, cx, r, stroke)
        txt.color = if (edit) Color.rgb(34, 211, 238) else Color.argb(230, 255, 255, 255)
        txt.textSize = w * 0.16f
        cv.drawText(number.toString(), cx, cx + w * 0.03f, txt)
        txt.textSize = w * 0.09f
        cv.drawText(if (edit) "hedef" else cpsText, cx, cx + w * 0.18f, txt)
    }
}

/** Oyun içinde paneli açan küçük sürüklenebilir düğme. */
class GearView(c: Context) : View(c) {
    var onTap: (() -> Unit)? = null
    var onMove: ((Float, Float) -> Unit)? = null
    var onEnd: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var dx = 0f; private var dy = 0f; private var moved = false
    private var sx = 0f; private var sy = 0f

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        p.style = Paint.Style.FILL; p.color = Color.argb(150, 25, 25, 35)
        cv.drawCircle(w / 2, w / 2, w / 2 - 2f, p)
        p.style = Paint.Style.STROKE; p.color = Color.argb(230, 255, 255, 255); p.strokeWidth = max(2f, w * 0.05f)
        cv.drawCircle(w / 2, w / 2, w / 2 - 2f, p)
        p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = max(3f, w * 0.08f)
        for (i in -1..1) cv.drawLine(w * 0.3f, w / 2 + i * w * 0.17f, w * 0.7f, w / 2 + i * w * 0.17f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; dx = sx; dy = sy; moved = false }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.rawX - sx, e.rawY - sy) > 12f) moved = true
                if (moved) { onMove?.invoke(e.rawX - dx, e.rawY - dy); dx = e.rawX; dy = e.rawY }
            }
            MotionEvent.ACTION_UP -> { if (moved) onEnd?.invoke() else onTap?.invoke() }
            MotionEvent.ACTION_CANCEL -> if (moved) onEnd?.invoke()
        }
        return true
    }
}
