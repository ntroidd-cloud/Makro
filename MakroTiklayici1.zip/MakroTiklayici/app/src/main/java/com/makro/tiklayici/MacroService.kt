package com.makro.tiklayici

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Düzenleme modunda: tek parmak sürükle, iki parmak büyüt/küçült */
class DragScale(
    ctx: Context,
    private val moved: (Float, Float) -> Unit,
    private val scaled: (Float) -> Unit,
    private val ended: () -> Unit
) : View.OnTouchListener {
    private val sd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            scaled(d.scaleFactor)
            return true
        }
    })
    private var lx = 0f
    private var ly = 0f

    override fun onTouch(v: View, e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                lx = e.rawX; ly = e.rawY
            }
            MotionEvent.ACTION_MOVE -> if (e.pointerCount == 1 && !sd.isInProgress) {
                moved(e.rawX - lx, e.rawY - ly)
                lx = e.rawX; ly = e.rawY
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> ended()
        }
        return true
    }
}

class MaxScroll(c: Context, private val maxH: Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
    }
}

class MacroService : AccessibilityService() {

    companion object {
        @Volatile var instance: MacroService? = null
        private val PRIMARY = Color.rgb(59, 130, 246)
        private val RED = Color.rgb(239, 68, 68)
        private val CARD = Color.argb(245, 24, 21, 32)
        private val GREY = Color.rgb(160, 165, 185)
        private val CHIP = Color.rgb(55, 52, 68)
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val overlays = HashMap<String, Overlay>()
    private var macros = mutableListOf<Macro>()
    private var curPkg = "" // şu an ekranda açık olan uygulama
    private var homePkg = ""

    private var gear: GearView? = null
    private var gearP: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var panelP: WindowManager.LayoutParams? = null
    private var panelBox: LinearLayout? = null
    private var selId = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = (v * resources.displayMetrics.density).toInt()

    private val poll = object : Runnable {
        override fun run() {
            foregroundFromWindows()?.let { setPkg(it) }
            h.postDelayed(this, 700)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            homePkg = packageManager.resolveActivity(i, 0)?.activityInfo?.packageName ?: ""
        } catch (e: Exception) { }
        refresh()
        h.removeCallbacks(poll)
        h.post(poll)
    }

    /** Öndeki uygulama penceresinin paketi. Olay kaçırılsa bile 0.7 sn'de bir kontrol edilir. */
    @Suppress("DEPRECATION")
    private fun foregroundFromWindows(): String? {
        return try {
            val ws = windows ?: return null
            var best: String? = null
            for (w in ws) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val r = w.root
                val pkg = r?.packageName?.toString()
                try { r?.recycle() } catch (e: Exception) { }
                if (pkg == null || pkg == "com.android.systemui") continue
                if (w.isActive || w.isFocused) return pkg
                if (best == null) best = pkg
            }
            best
        } catch (e: Exception) { null }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val t = event.eventType
        if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && t != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
        val w = foregroundFromWindows()
        if (w != null) { setPkg(w); return }
        if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: ""
        if (pkg == packageName && !cls.endsWith("MainActivity")) return // kendi tuşlarımız / paneller
        if (pkg == "com.android.systemui" || isIme(pkg)) return // bildirim paneli, klavye
        setPkg(pkg)
    }

    private fun setPkg(p: String) {
        if (p == curPkg) return
        curPkg = p
        if (p != packageName && p != homePkg) Store.setStr(this, "lastSeen", p)
        redraw()
    }

    private fun isIme(pkg: String): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_INPUT_METHODS) ?: return false
        return s.contains("$pkg/")
    }

    override fun onInterrupt() {}

    // Ekran dönünce: tıklamayı durdur, tuşları o yönün kendi konumuna taşı
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::wm.isInitialized) return
        overlays.values.forEach { it.stop() }
        redraw()
        h.postDelayed({ redraw() }, 300)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        clearAll(); instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        clearAll(); instance = null
        super.onDestroy()
    }

    private fun clearAll() {
        h.removeCallbacks(poll)
        overlays.values.forEach { it.destroy() }
        overlays.clear()
        hidePanel(); hideGear()
    }

    private fun detach(v: View) {
        if (v.parent != null) runCatching { wm.removeView(v) }
    }

    @Suppress("DEPRECATION")
    private fun screen(): Point {
        val p = Point()
        wm.defaultDisplay.getRealSize(p)
        return p
    }

    @Suppress("DEPRECATION")
    private fun lp(w: Int, hh: Int) = WindowManager.LayoutParams(
        w, hh, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_SPLIT_TOUCH, // oyundaki parmakla aynı anda çalışsın (ghosting önleme)
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun here(m: Macro): Boolean =
        if (m.pkg.isEmpty()) (curPkg != packageName && curPkg != homePkg) else m.pkg == curPkg

    /** Uygulamadan her değişiklikte çağrılır (kayıtlı makroları yeniden okur) */
    fun refresh() {
        if (!::wm.isInitialized) return
        macros = Store.load(this)
        redraw()
        if (panel != null) buildPanel()
    }

    /** Elimizdeki makrolarla ekranı yeniler (diskten okumaz) */
    private fun redraw() {
        if (!::wm.isInitialized) return
        val ids = macros.map { it.id }.toSet()
        overlays.keys.filter { it !in ids }.forEach { overlays.remove(it)?.destroy() }
        val visible = Store.getBool(this, "visible", true)
        val edit = Store.getBool(this, "edit", false)
        val sz = screen()
        macros.forEach { m ->
            overlays.getOrPut(m.id) { Overlay() }.update(m, visible && (m.enabled || edit) && here(m), edit, sz)
        }
        val anyHere = macros.any { here(it) }
        if (visible && !edit && anyHere && Store.getBool(this, "gear", true)) showGear() else hideGear()
        if (visible && edit && anyHere) showPanel() else hidePanel()
    }

    // ---------- ☰ panel düğmesi ----------

    private fun gearKeys(): Pair<String, String> {
        val land = screen().let { it.x >= it.y }
        return if (land) Pair("glx", "gly") else Pair("gpx", "gpy")
    }

    private fun showGear() {
        val sz = screen()
        val (kx, ky) = gearKeys()
        val s = dp(44)
        val px = (Store.getF(this, kx, if (kx == "glx") 0.04f else 0.05f) * sz.x).toInt()
        val py = (Store.getF(this, ky, if (ky == "gly") 0.16f else 0.14f) * sz.y).toInt()
        val g = gear
        if (g != null) {
            gearP?.let { it.x = px; it.y = py; runCatching { wm.updateViewLayout(g, it) } }
            return
        }
        val v = GearView(this)
        val p = lp(s, s)
        p.x = px; p.y = py
        v.alpha = 0.75f
        v.onTap = { Store.setBool(this, "edit", true); redraw() }
        v.onMove = { dx, dy ->
            val sc = screen()
            val (ax, ay) = gearKeys()
            p.x = (p.x + dx).toInt().coerceIn(0, sc.x - s)
            p.y = (p.y + dy).toInt().coerceIn(0, sc.y - s)
            runCatching { wm.updateViewLayout(v, p) }
        }
        v.onEnd = {
            val sc = screen()
            val (ax, ay) = gearKeys()
            Store.setF(this, ax, p.x.toFloat() / sc.x)
            Store.setF(this, ay, p.y.toFloat() / sc.y)
        }
        if (runCatching { wm.addView(v, p) }.isSuccess) { gear = v; gearP = p }
    }

    private fun hideGear() { gear?.let { detach(it) }; gear = null; gearP = null }

    // ---------- oyun içi Makro Paneli ----------

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = r.toFloat() }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun pbtn(text: String, color: Int, onClick: () -> Unit) = tv(text, 13f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER
        background = rounded(color, dp(10))
        setPadding(dp(10), dp(9), dp(10), dp(9))
        setOnClickListener { onClick() }
    }

    private fun showPanel() {
        if (panel != null) return
        val sz = screen()
        val land = sz.x >= sz.y
        val maxH = if (land) sz.y - dp(24) - dp(56) else (sz.y * 0.55f).toInt() - dp(56)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD, dp(16))
            setPadding(dp(14), dp(8), dp(14), dp(12))
        }
        val head = tv("☰  Makro Paneli  (buradan sürükle)", 14f, Color.WHITE, true).apply { setPadding(0, dp(4), 0, dp(8)) }
        root.addView(head)
        val sv = MaxScroll(this, maxH)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sv.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(sv)
        val pw = if (land) minOf(dp(330), sz.x / 2) else sz.x - dp(24)
        val p = lp(pw, WindowManager.LayoutParams.WRAP_CONTENT)
        p.x = dp(12)
        p.y = if (land) dp(12) else (sz.y * 0.42f).toInt()
        var lx = 0f; var ly = 0f
        head.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    p.x += (e.rawX - lx).toInt(); p.y += (e.rawY - ly).toInt()
                    lx = e.rawX; ly = e.rawY
                    runCatching { wm.updateViewLayout(root, p) }
                }
            }
            true
        }
        if (runCatching { wm.addView(root, p) }.isSuccess) { panel = root; panelP = p; panelBox = box; buildPanel() }
    }

    private fun hidePanel() { panel?.let { detach(it) }; panel = null; panelP = null; panelBox = null }

    private fun closeEdit() {
        Store.setBool(this, "edit", false)
        Store.save(this, macros)
        redraw()
    }

    private fun selected(): Macro? {
        val m = macros.firstOrNull { it.id == selId && here(it) } ?: macros.firstOrNull { here(it) }
        selId = m?.id ?: ""
        return m
    }

    private fun appName(): String = try {
        packageManager.getApplicationInfo(curPkg, 0).loadLabel(packageManager).toString()
    } catch (e: Exception) { curPkg }

    private fun buildPanel() {
        val box = panelBox ?: return
        box.removeAllViews()
        val list = macros.filter { here(it) }
        val m = selected()

        box.addView(tv("Uygulama: ${appName()}", 11f, GREY))

        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(4)) }
        for (x in list) {
            chips.addView(tv(x.name, 12f, Color.WHITE, true).apply {
                background = rounded(if (x.id == selId) PRIMARY else CHIP, dp(14))
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener { selId = x.id; buildPanel() }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        chips.addView(tv("+ Yeni", 12f, Color.WHITE, true).apply {
            background = rounded(Color.rgb(34, 150, 90), dp(14))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { addMacroHere() }
        })
        hs.addView(chips)
        box.addView(hs)

        if (m != null) {
            val seg = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, 0) }
            fun segBtn(t: String, on: Boolean, click: () -> Unit) = tv(t, 12f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = rounded(if (on) PRIMARY else CHIP, dp(10))
                setPadding(0, dp(9), 0, dp(9))
                setOnClickListener { click() }
            }
            seg.addView(segBtn("BASILI TUT", !m.toggleMode) { setToggle(m, false) },
                LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
            seg.addView(segBtn("AÇ-KAPA", m.toggleMode) { setToggle(m, true) }, LinearLayout.LayoutParams(0, -2, 1f))
            box.addView(seg)
            box.addView(tv(if (m.toggleMode) "Tuşa dokun başlat, tekrar dokun durdur." else "Tuşa basılı tuttukça tıklar, bırakınca durur.", 11f, GREY).apply { setPadding(0, dp(4), 0, 0) })

            box.addView(slider("HIZ", " tık/sn", 1, 30, m.cps) { m.cps = it; overlays[m.id]?.refreshView() })
            box.addView(slider("TUŞ BOYUTU", "", 40, 220, m.triggerDp.roundToInt()) { m.triggerDp = it.toFloat(); overlays[m.id]?.refreshView() })
            box.addView(slider("HEDEF ALAN", "", 30, 300, m.targetDp.roundToInt()) { m.targetDp = it.toFloat(); overlays[m.id]?.refreshView() })
            box.addView(slider("SAYDAMLIK", "%", 20, 100, (m.opacity * 100).roundToInt().coerceIn(20, 100)) { m.opacity = it / 100f })
            box.addView(tv("Saydamlık, ✓ TAMAM'a basınca oyunda görünür.", 10f, GREY))

            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
            row.addView(pbtn(if (m.enabled) "Etkin: Evet" else "Etkin: Hayır", Color.rgb(70, 66, 90)) {
                m.enabled = !m.enabled; Store.save(this, macros); buildPanel()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
            row.addView(pbtn("Sil", RED) { deleteSelected() }, LinearLayout.LayoutParams(0, -2, 1f))
            box.addView(row)
        }
        box.addView(pbtn("✓  TAMAM", PRIMARY) { closeEdit() }.apply { setPadding(dp(10), dp(12), dp(10), dp(12)) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
    }

    private fun setToggle(m: Macro, on: Boolean) {
        m.toggleMode = on
        Store.save(this, macros)
        buildPanel()
    }

    private fun slider(title: String, unit: String, lo: Int, hi: Int, value: Int, onChange: (Int) -> Unit): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val vt = tv("$value$unit", 14f, Color.WHITE, true).apply { gravity = Gravity.END }
        row.addView(tv(title, 11f, GREY), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(vt, LinearLayout.LayoutParams(-2, -2))
        val sb = SeekBar(this).apply {
            this.max = hi - lo
            progress = (value - lo).coerceIn(0, hi - lo)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    vt.text = "${p + lo}$unit"
                    if (fromUser) onChange(p + lo)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { Store.save(this@MacroService, macros) }
            })
        }
        col.addView(row); col.addView(sb)
        return col
    }

    private fun addMacroHere() {
        val nm = Macro.create(macros.size, if (curPkg == packageName) "" else curPkg)
        macros.add(nm)
        selId = nm.id
        Store.save(this, macros)
        redraw()
        buildPanel()
    }

    private fun deleteSelected() {
        val m = selected() ?: return
        overlays.remove(m.id)?.destroy()
        macros.removeAll { it.id == m.id }
        selId = ""
        Store.save(this, macros)
        if (macros.none { here(it) }) closeEdit() else { redraw(); buildPanel() }
    }

    private fun selectMacro(id: String) {
        if (selId != id) { selId = id; buildPanel() }
    }

    /** Bir makro = tuş (basılınca çalıştırır) + hedef halka (içine rastgele tıklar) */
    inner class Overlay {
        lateinit var m: Macro
        private val trigger = TriggerView(this@MacroService)
        private val target = RingView(this@MacroService)
        private val tp = lp(0, 0)
        private val gp = lp(0, 0)
        private var firing = false
        private var edit = false
        private var sz = Point(1, 1)
        private val rnd = java.util.Random()

        private val loop = object : Runnable {
            override fun run() {
                if (!firing) return
                tap()
                h.postDelayed(this, (1000L / m.cps).coerceAtLeast(20L))
            }
        }

        private val dragT = DragScale(this@MacroService,
            { dx, dy -> shift(0, dx, dy) },
            { f -> m.triggerDp = (m.triggerDp * f).coerceIn(40f, 220f); relayout() },
            { Store.save(this@MacroService, macros); buildPanel() })
        private val dragG = DragScale(this@MacroService,
            { dx, dy -> shift(2, dx, dy) },
            { f -> m.targetDp = (m.targetDp * f).coerceIn(30f, 300f); relayout() },
            { Store.save(this@MacroService, macros); buildPanel() })

        init {
            trigger.setOnTouchListener { v, e ->
                if (edit) {
                    if (e.actionMasked == MotionEvent.ACTION_DOWN) selectMacro(m.id)
                    dragT.onTouch(v, e)
                } else press(e)
            }
            target.setOnTouchListener { v, e ->
                if (edit) {
                    if (e.actionMasked == MotionEvent.ACTION_DOWN) selectMacro(m.id)
                    dragG.onTouch(v, e)
                } else false
            }
        }

        private fun press(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> if (m.toggleMode && firing) stop() else start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (!m.toggleMode) stop()
            }
            return true
        }

        fun update(macro: Macro, show: Boolean, editMode: Boolean, size: Point) {
            m = macro; edit = editMode; sz = size
            if (!show) { stop(); detach(trigger); detach(target); return }
            if (edit) stop()
            style(); relayout()
        }

        /** Panelden boyut/hız değişince */
        fun refreshView() { style(); relayout() }

        private fun start() {
            if (firing) return
            firing = true; style(); h.post(loop)
        }

        fun stop() {
            firing = false
            h.removeCallbacks(loop)
            if (::m.isInitialized) style()
        }

        fun destroy() {
            stop(); detach(trigger); detach(target)
        }

        private fun shift(k: Int, dx: Float, dy: Float) {
            val b = (if (sz.x >= sz.y) 0 else 4) + k
            m.pos[b] = (m.pos[b] + dx / sz.x).coerceIn(0f, 1f)
            m.pos[b + 1] = (m.pos[b + 1] + dy / sz.y).coerceIn(0f, 1f)
            relayout()
        }

        private fun relayout() {
            place(trigger, tp, 0, m.triggerDp, false)
            place(target, gp, 2, m.targetDp, true)
        }

        @Suppress("DEPRECATION")
        private fun place(v: View, p: WindowManager.LayoutParams, k: Int, size: Float, isTarget: Boolean) {
            val px = dpf(size)
            val b = (if (sz.x >= sz.y) 0 else 4) + k
            p.width = px; p.height = px
            p.x = (m.pos[b] * sz.x - px / 2f).toInt()
            p.y = (m.pos[b + 1] * sz.y - px / 2f).toInt()
            val nt = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            // Hedef halka dokunmaya kapalı: böylece gönderilen tıklamalar altındaki oyuna geçer
            p.flags = if (isTarget && !edit) p.flags or nt else p.flags and nt.inv()
            if (v.parent == null) wm.addView(v, p) else wm.updateViewLayout(v, p)
        }

        private fun style() {
            trigger.edit = edit; trigger.active = firing
            trigger.label = m.name
            trigger.alpha = if (edit) 1f else m.opacity
            trigger.invalidate()
            target.edit = edit
            target.number = macros.indexOfFirst { it.id == m.id } + 1
            target.cpsText = "${m.cps} CPS"
            target.alpha = if (edit) 1f else max(0.4f, m.opacity)
            target.invalidate()
        }

        private fun tap() {
            val r = target.width / 2f
            if (r <= 0f) return
            val loc = IntArray(2)
            target.getLocationOnScreen(loc)
            val ang = rnd.nextDouble() * 2 * Math.PI
            val d = sqrt(rnd.nextDouble()) * r * 0.8
            val x = loc[0] + r + (cos(ang) * d).toFloat()
            val y = loc[1] + r + (sin(ang) * d).toFloat()
            val path = Path().apply { moveTo(x, y) }
            val dur = (1000L / m.cps - 10L).coerceIn(1L, 20L)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
            dispatchGesture(g, null, null)
            target.pulse()
        }
    }
}
