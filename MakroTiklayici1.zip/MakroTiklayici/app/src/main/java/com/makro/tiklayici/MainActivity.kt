package com.makro.tiklayici

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private var macros = mutableListOf<Macro>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(40))
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun accessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/") && s.contains("MacroService")
    }

    private fun persist() {
        Store.save(this, macros)
        MacroService.instance?.refresh()
    }

    private fun render() {
        root.removeAllViews()
        macros = Store.load(this)
        root.addView(txt("Makro Tıklayıcı", 28f, true))
        root.addView(txt("Oyunun üstünde yüzen, boyutu ve hızı ayarlanabilir tıklama tuşları", 13f, top = 4))
        root.addView(setupCard())
        root.addView(gamesCard())
        root.addView(controlsCard())
        macros.forEach { root.addView(macroCard(it)) }
        root.addView(MaterialButton(this).apply {
            text = "+ Yeni makro ekle"
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) }
            setOnClickListener {
                macros.add(Macro.create(macros.size, Store.getStr(this@MainActivity, "lastPkg", ""))); persist(); render()
            }
        })
        root.addView(txt("Not: Online sunucularda otomatik tıklama kuralları ihlal edebilir ve ban sebebi olabilir.", 12f, top = 16))
    }

    // ---------- küçük yardımcılar ----------

    private fun txt(t: String, size: Float = 14f, bold: Boolean = false, top: Int = 0) = TextView(this).apply {
        text = t; textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(top), 0, 0)
    }

    private fun card(content: LinearLayout.() -> Unit) = MaterialCardView(this).apply {
        radius = dp(20).toFloat(); cardElevation = 0f
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(14) }
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            content()
        })
    }

    private fun btn(label: String, onClick: () -> Unit) = MaterialButton(this).apply {
        text = label
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun sw(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = MaterialSwitch(this).apply {
        text = label; isChecked = checked
        setOnCheckedChangeListener { _, c -> onChange(c) }
    }

    private fun slider(
        label: (Float) -> String, from: Float, to: Float, step: Float, value: Float, onChange: (Float) -> Unit
    ): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
        val v0 = (((value - from) / step).roundToInt() * step + from).coerceIn(from, to)
        val tv = TextView(this).apply { text = label(v0); textSize = 13f }
        val sl = Slider(this).apply {
            valueFrom = from; valueTo = to; stepSize = step; this.value = v0
            addOnChangeListener { _, v, fromUser ->
                if (fromUser) { tv.text = label(v); onChange(v) }
            }
        }
        box.addView(tv); box.addView(sl)
        return box
    }

    private fun appLabel(pkg: String): String {
        if (pkg.isEmpty()) return "Her uygulamada"
        return try {
            packageManager.getApplicationInfo(pkg, 0).loadLabel(packageManager).toString()
        } catch (e: Exception) { pkg }
    }

    /** Kurulu uygulamalardan birini seçtirir. allowAll = listenin başına "Her uygulamada" seçeneği ekler. */
    private fun chooseApp(title: String, allowAll: Boolean, onPick: (String) -> Unit) {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        val names = ((if (allowAll) listOf("Her uygulamada (hepsi)") else emptyList()) + apps.map { it.first }).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(names) { _, i ->
                val k = if (allowAll) i - 1 else i
                onPick(if (k < 0) "" else apps[k].second)
            }.show()
    }

    private fun pickApp(m: Macro) = chooseApp("Hangi uygulamada çalışsın?", true) { pkg ->
        m.pkg = pkg
        Store.setStr(this, "lastPkg", pkg)
        persist(); render()
    }

    /** Oyunu buradan aç: tuşlar oyun öne gelince kendiliğinden çıkar. */
    private fun launchGame(pkg: String) {
        if (!accessibilityOn()) {
            Toast.makeText(this, "Önce erişilebilirlik iznini ver", Toast.LENGTH_LONG).show(); return
        }
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            Toast.makeText(this, "Uygulama açılamadı", Toast.LENGTH_SHORT).show(); return
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    // ---------- kartlar ----------

    private fun setupCard() = card {
        val on = accessibilityOn()
        addView(txt(if (on) "✅ Erişilebilirlik izni verildi" else "⚠️ Önce izin vermen gerekiyor", 16f, true))
        if (!on) {
            addView(txt(
                "1) Aşağıdaki butona bas\n2) \"İndirilen uygulamalar\" → Makro Tıklayıcı\n3) Aç ve \"İzin ver\" de\n\n" +
                    "Anahtar gri/kapalıysa: Uygulama bilgisi → sağ üst ⋮ → \"Kısıtlanmış ayarlara izin ver\", sonra tekrar dene.",
                13f, top = 8
            ))
            addView(btn("Erişilebilirlik ayarlarını aç") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        }
        addView(txt("Oyundayken tuşların kapanmaması için pil kısıtlamasını kaldır (Pil → Kısıtlama yok / Otomatik başlat açık).", 13f, top = 12))
        addView(btn("Pil ayarlarını aç") {
            runCatching { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })
    }

    private fun gamesCard() = card {
        addView(txt("Oyunlar", 18f, true))
        val pkgs = macros.map { it.pkg }.filter { it.isNotEmpty() }.distinct()
        if (pkgs.isEmpty()) {
            addView(txt("Henüz oyun eklenmedi. Oyunu ekle, sonra buradan aç: tuşlar oyunda otomatik çıkar.", 13f, top = 4))
        }
        pkgs.forEach { pkg ->
            val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(MaterialButton(this@MainActivity).apply {
                text = "▶  " + appLabel(pkg)
                layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 3f).apply { topMargin = dp(8); rightMargin = dp(6) }
                setOnClickListener { launchGame(pkg) }
            })
            row.addView(MaterialButton(this@MainActivity).apply {
                text = "Kaldır"
                layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1.2f).apply { topMargin = dp(8) }
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("${appLabel(pkg)} kaldırılsın mı?")
                        .setMessage("Bu oyuna bağlı makrolar da silinir.")
                        .setPositiveButton("Kaldır") { _, _ -> macros.removeAll { it.pkg == pkg }; persist(); render() }
                        .setNegativeButton("Vazgeç", null).show()
                }
            })
            addView(row)
        }
        addView(btn("+ Oyun ekle") {
            chooseApp("Hangi oyunu ekleyelim?", false) { pkg ->
                if (macros.none { it.pkg == pkg }) macros.add(Macro.create(macros.size, pkg))
                Store.setStr(this@MainActivity, "lastPkg", pkg)
                persist(); render()
            }
        })
    }

    private fun controlsCard() = card {
        addView(sw("Tuşları oyunda göster", Store.getBool(this@MainActivity, "visible", true)) {
            Store.setBool(this@MainActivity, "visible", it); MacroService.instance?.refresh()
        })
        addView(sw("Oyunda ☰ panel düğmesi", Store.getBool(this@MainActivity, "gear", true)) {
            Store.setBool(this@MainActivity, "gear", it); MacroService.instance?.refresh()
        })
        addView(sw("Ekranı karart (OLED koruma, tıklama sürer)", Store.getBool(this@MainActivity, "dim", false)) {
            Store.setBool(this@MainActivity, "dim", it); MacroService.instance?.refresh()
        })
        addView(txt("Karartma açıkken ekran açık kalır ve tıklamalar devam eder. Kapatmak için oyundaki ☰ düğmesine dokun.", 12f, top = 2))
        addView(sw("Düzenleme modu (oyunda panel açık)", Store.getBool(this@MainActivity, "edit", false)) {
            Store.setBool(this@MainActivity, "edit", it); MacroService.instance?.refresh()
        })
        addView(txt(
            "Oyuna girince ekranda küçük bir ☰ düğmesi çıkar (sürükleyip yerini değiştirebilirsin). " +
                "Dokununca oyun içinde Makro Paneli açılır: tuşu ve hedef halkayı parmakla sürükle, iki parmakla büyüt/küçült; " +
                "hız, boyut, mod ve saydamlığı panelden ayarla; yeni makro ekle veya sil. Bitince panelde \"✓ TAMAM\"a bas.\n\n" +
                "Yatay ve dikey konumlar ayrı kaydedilir: ekranı döndürünce tuşlar kendi yerine geçer.",
            12f, top = 6
        ))
        val seen = Store.getStr(this@MainActivity, "lastSeen", "")
        addView(txt(
            "Servisin en son gördüğü uygulama: " + (if (seen.isEmpty()) "henüz yok (oyunu bir kez aç)" else "${appLabel(seen)} ($seen)") +
                "\n\nTuşlar oyunda çıkmıyorsa: makronun \"Uygulama\" ayarını geçici olarak \"Her uygulamada\" yap. " +
                "O zaman çıkıyorsa sorun uygulama seçimindedir, yukarıdaki paket adını seçtiğin uygulamayla karşılaştır.",
            12f, top = 10
        ))
    }

    private fun macroCard(m: Macro) = card {
        val head = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(EditText(this@MainActivity).apply {
            setText(m.name); setSingleLine()
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
            doAfterTextChanged { m.name = it.toString().ifBlank { "Makro" }; persist() }
        })
        head.addView(MaterialSwitch(this@MainActivity).apply {
            isChecked = m.enabled
            setOnCheckedChangeListener { _, c -> m.enabled = c; persist() }
        })
        addView(head)
        addView(btn("Mod: " + listOf("Tıklama", "Basılı tut", "Kaydır")[m.mode.coerceIn(0, 2)]) {
            AlertDialog.Builder(this@MainActivity).setTitle("Mod")
                .setItems(arrayOf("Tıklama (hızlı tıklar)", "Basılı tut (parmağı hedefte tutar)", "Kaydır (hedefte sürekli kaydırır)")) { _, i ->
                    m.mode = i; persist(); render()
                }.show()
        })
        if (m.mode == 2) {
            addView(btn("Kaydırma yönü: " + listOf("Yukarı", "Aşağı", "Sol", "Sağ")[m.swipeDir.coerceIn(0, 3)]) {
                AlertDialog.Builder(this@MainActivity).setTitle("Yön")
                    .setItems(arrayOf("Yukarı", "Aşağı", "Sol", "Sağ")) { _, i -> m.swipeDir = i; persist(); render() }.show()
            })
        }
        if (m.mode != 1) {
            addView(slider({ "Hız: ${it.roundToInt()} " + (if (m.mode == 2) "kaydırma/saniye" else "tık/saniye") }, 1f, 30f, 1f, m.cps.toFloat()) {
                m.cps = it.roundToInt(); persist()
            })
        }
        addView(slider({ if (it.roundToInt() == 0) "Çalışma süresi: ara vermeden" else "Çalışma süresi: ${it.roundToInt()} sn" }, 0f, 120f, 1f, m.burstSec.toFloat()) {
            m.burstSec = it.roundToInt(); persist()
        })
        addView(slider({ "Bekleme süresi: ${it.roundToInt()} sn (çalışma süresi 0 ise kullanılmaz)" }, 1f, 120f, 1f, m.pauseSec.coerceAtLeast(1).toFloat()) {
            m.pauseSec = it.roundToInt(); persist()
        })
        addView(slider({ "Tuş boyutu: ${it.roundToInt()}" }, 40f, 220f, 1f, m.triggerDp) {
            m.triggerDp = it; persist()
        })
        addView(slider({ "Hedef alan boyutu: ${it.roundToInt()}" }, 30f, 300f, 1f, m.targetDp) {
            m.targetDp = it; persist()
        })
        addView(slider({ "Saydamlık: %${it.roundToInt()}" }, 20f, 100f, 5f, m.opacity * 100f) {
            m.opacity = it / 100f; persist()
        })
        addView(sw("Aç-kapa modu (dokun başlat, tekrar dokun durdur)", m.toggleMode) {
            m.toggleMode = it; persist()
        })
        addView(txt("Kapalıyken: tuşa basılı tuttukça tıklar, bırakınca durur.", 12f, top = 2))
        addView(btn("Uygulama: " + appLabel(m.pkg)) { pickApp(m) })
        addView(txt("Seçtiğin uygulama öne gelince tuşlar kendiliğinden çıkar, başka uygulamaya geçince kaybolur.", 12f, top = 2))
        addView(btn("Makroyu sil") {
            macros.removeAll { it.id == m.id }; persist(); render()
        })
    }
}
