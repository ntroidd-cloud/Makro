package com.makro.tiklayici

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private var macros = mutableListOf<Macro>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(40))
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun accessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/") && s.contains("MacroService")
    }

    private fun persist() {
        Store.save(this, macros)
        MacroService.instance?.refresh()
    }

    private fun render() {
        root.removeAllViews()
        macros = Store.load(this)
        root.addView(txt("Makro Tıklayıcı", 28f, true))
        root.addView(txt("Oyunun üstünde yüzen, boyutu ve hızı ayarlanabilir tıklama tuşları", 13f, top = 4))
        root.addView(setupCard())
        root.addView(controlsCard())
        macros.forEach { root.addView(macroCard(it)) }
        root.addView(MaterialButton(this).apply {
            text = "+ Yeni makro ekle"
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) }
            setOnClickListener {
                macros.add(Macro.create(macros.size, Store.getStr(this@MainActivity, "lastPkg", ""))); persist(); render()
            }
        })
        root.addView(txt("Not: Online sunucularda otomatik tıklama kuralları ihlal edebilir ve ban sebebi olabilir.", 12f, top = 16))
    }

    // ---------- küçük yardımcılar ----------

    private fun txt(t: String, size: Float = 14f, bold: Boolean = false, top: Int = 0) = TextView(this).apply {
        text = t; textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(top), 0, 0)
    }

    private fun card(content: LinearLayout.() -> Unit) = MaterialCardView(this).apply {
        radius = dp(20).toFloat(); cardElevation = 0f
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(14) }
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            content()
        })
    }

    private fun btn(label: String, onClick: () -> Unit) = MaterialButton(this).apply {
        text = label
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun sw(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = MaterialSwitch(this).apply {
        text = label; isChecked = checked
        setOnCheckedChangeListener { _, c -> onChange(c) }
    }

    private fun slider(
        label: (Float) -> String, from: Float, to: Float, step: Float, value: Float, onChange: (Float) -> Unit
    ): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
        val v0 = (((value - from) / step).roundToInt() * step + from).coerceIn(from, to)
        val tv = TextView(this).apply { text = label(v0); textSize = 13f }
        val sl = Slider(this).apply {
            valueFrom = from; valueTo = to; stepSize = step; this.value = v0
            addOnChangeListener { _, v, fromUser ->
                if (fromUser) { tv.text = label(v); onChange(v) }
            }
        }
        box.addView(tv); box.addView(sl)
        return box
    }

    private fun appLabel(pkg: String): String {
        if (pkg.isEmpty()) return "Her uygulamada"
        return try {
            packageManager.getApplicationInfo(pkg, 0).loadLabel(packageManager).toString()
        } catch (e: Exception) { pkg }
    }

    private fun pickApp(m: Macro) {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        val names = (listOf("Her uygulamada (hepsi)") + apps.map { it.first }).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Hangi uygulamada çalışsın?")
            .setItems(names) { _, i ->
                m.pkg = if (i == 0) "" else apps[i - 1].second
                Store.setStr(this, "lastPkg", m.pkg)
                persist(); render()
            }.show()
    }

    // ---------- kartlar ----------

    private fun setupCard() = card {
        val on = accessibilityOn()
        addView(txt(if (on) "✅ Erişilebilirlik izni verildi" else "⚠️ Önce izin vermen gerekiyor", 16f, true))
        if (!on) {
            addView(txt(
                "1) Aşağıdaki butona bas\n2) \"İndirilen uygulamalar\" → Makro Tıklayıcı\n3) Aç ve \"İzin ver\" de\n\n" +
                    "Anahtar gri/kapalıysa: Uygulama bilgisi → sağ üst ⋮ → \"Kısıtlanmış ayarlara izin ver\", sonra tekrar dene.",
                13f, top = 8
            ))
            addView(btn("Erişilebilirlik ayarlarını aç") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        }
        addView(txt("Oyundayken tuşların kapanmaması için pil kısıtlamasını kaldır (Pil → Kısıtlama yok / Otomatik başlat açık).", 13f, top = 12))
        addView(btn("Pil ayarlarını aç") {
            runCatching { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })
    }

    private fun controlsCard() = card {
        addView(sw("Tuşları oyunda göster", Store.getBool(this@MainActivity, "visible", true)) {
            Store.setBool(this@MainActivity, "visible", it); MacroService.instance?.refresh()
        })
        addView(sw("Düzenleme modu", Store.getBool(this@MainActivity, "edit", false)) {
            Store.setBool(this@MainActivity, "edit", it); MacroService.instance?.refresh()
        })
        addView(txt(
            "Düzenleme modunda tuşu ve hedef halkayı parmakla sürükle, iki parmakla büyüt/küçült. " +
                "Bitince oyunda üstte çıkan \"✓ Düzenlemeyi bitir\" yazısına dokun.\n\n" +
                "Yatay ve dikey konumlar ayrı kaydedilir: ekranı döndürünce tuşlar kendi yerine geçer.",
            12f, top = 6
        ))
    }

    private fun macroCard(m: Macro) = card {
        val head = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(EditText(this@MainActivity).apply {
            setText(m.name); setSingleLine()
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
            doAfterTextChanged { m.name = it.toString().ifBlank { "Makro" }; persist() }
        })
        head.addView(MaterialSwitch(this@MainActivity).apply {
            isChecked = m.enabled
            setOnCheckedChangeListener { _, c -> m.enabled = c; persist() }
        })
        addView(head)
        addView(slider({ "Hız: ${it.roundToInt()} tık/saniye" }, 1f, 30f, 1f, m.cps.toFloat()) {
            m.cps = it.roundToInt(); persist()
        })
        addView(slider({ "Tuş boyutu: ${it.roundToInt()}" }, 40f, 220f, 1f, m.triggerDp) {
            m.triggerDp = it; persist()
        })
        addView(slider({ "Hedef alan boyutu: ${it.roundToInt()}" }, 30f, 300f, 1f, m.targetDp) {
            m.targetDp = it; persist()
        })
        addView(slider({ "Saydamlık: %${it.roundToInt()}" }, 20f, 100f, 5f, m.opacity * 100f) {
            m.opacity = it / 100f; persist()
        })
        addView(sw("Aç-kapa modu (dokun başlat, tekrar dokun durdur)", m.toggleMode) {
            m.toggleMode = it; persist()
        })
        addView(txt("Kapalıyken: tuşa basılı tuttukça tıklar, bırakınca durur.", 12f, top = 2))
        addView(btn("Uygulama: " + appLabel(m.pkg)) { pickApp(m) })
        addView(txt("Seçtiğin uygulama öne gelince tuşlar kendiliğinden çıkar, başka uygulamaya geçince kaybolur.", 12f, top = 2))
        addView(btn("Makroyu sil") {
            macros.removeAll { it.id == m.id }; persist(); render()
        })
    }
}
