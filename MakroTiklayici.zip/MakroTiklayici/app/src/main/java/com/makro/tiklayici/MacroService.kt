package com.makro.tiklayici

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Düzenleme modunda: tek parmak sürükle, iki parmak büyüt/küçült */
class DragScale(
    ctx: Context,
    private val moved: (Float, Float) -> Unit,
    private val scaled: (Float) -> Unit,
    private val ended: () -> Unit
) : View.OnTouchListener {
    private val sd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            scaled(d.scaleFactor)
            return true
        }
    })
    private var lx = 0f
    private var ly = 0f

    override fun onTouch(v: View, e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                lx = e.rawX; ly = e.rawY
            }
            MotionEvent.ACTION_MOVE -> if (e.pointerCount == 1 && !sd.isInProgress) {
                moved(e.rawX - lx, e.rawY - ly)
                lx = e.rawX; ly = e.rawY
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> ended()
        }
        return true
    }
}

class MacroService : AccessibilityService() {

    companion object {
        @Volatile var instance: MacroService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val overlays = HashMap<String, Overlay>()
    private var macros = mutableListOf<Macro>()
    private var pill: TextView? = null
    private var curPkg = "" // şu an ekranda açık olan uygulama

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        refresh()
    }

    // Hangi uygulama öndeyse onu takip eder; tuşlar sadece seçilen uygulamada görünür
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: ""
        if (cls.startsWith("android.widget.") || cls.startsWith("android.view.")) return // kendi tuşlarımız
        if (pkg == "com.android.systemui" || isIme(pkg)) return // bildirim paneli, klavye
        if (pkg != curPkg) {
            curPkg = pkg
            refresh()
        }
    }

    private fun isIme(pkg: String): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_INPUT_METHODS) ?: return false
        return s.contains("$pkg/")
    }
    override fun onInterrupt() {}

    // Ekran dönünce: tıklamayı durdur, tuşları o yönün kendi konumuna taşı
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::wm.isInitialized) return
        overlays.values.forEach { it.stop() }
        refresh()
        h.postDelayed({ refresh() }, 300)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        clearAll(); instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        clearAll(); instance = null
        super.onDestroy()
    }

    private fun clearAll() {
        overlays.values.forEach { it.destroy() }
        overlays.clear()
        pill?.let { detach(it) }
    }

    private fun detach(v: View) {
        if (v.parent != null) runCatching { wm.removeView(v) }
    }

    @Suppress("DEPRECATION")
    private fun screen(): Point {
        val p = Point()
        wm.defaultDisplay.getRealSize(p)
        return p
    }

    @Suppress("DEPRECATION")
    private fun lp(w: Int, hh: Int) = WindowManager.LayoutParams(
        w, hh, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_SPLIT_TOUCH, // oyundaki parmakla aynı anda çalışsın (ghosting önleme)
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    /** Uygulamadan her değişiklikte çağrılır */
    fun refresh() {
        if (!::wm.isInitialized) return
        macros = Store.load(this)
        val ids = macros.map { it.id }.toSet()
        overlays.keys.filter { it !in ids }.forEach { overlays.remove(it)?.destroy() }
        val visible = Store.getBool(this, "visible", true)
        val edit = Store.getBool(this, "edit", false)
        val sz = screen()
        macros.forEach { m ->
            val here = m.pkg.isEmpty() || m.pkg == curPkg
            overlays.getOrPut(m.id) { Overlay() }.update(m, visible && m.enabled && here, edit, sz)
        }
        updatePill(edit && visible)
    }

    private fun updatePill(show: Boolean) {
        if (!show) { pill?.let { detach(it) }; return }
        val v = pill ?: TextView(this).apply {
            text = "✓ Düzenlemeyi bitir"
            setTextColor(Color.WHITE); textSize = 14f; setTypeface(null, Typeface.BOLD)
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat(); setColor(Color.parseColor("#F59E0B"))
            }
            setOnClickListener {
                Store.setBool(this@MacroService, "edit", false)
                refresh()
            }
        }.also { pill = it }
        if (v.parent == null) {
            val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
            p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            p.y = dp(24)
            wm.addView(v, p)
        }
    }

    /** Bir makro = tuş (basılınca çalıştırır) + hedef halka (içine rastgele tıklar) */
    inner class Overlay {
        lateinit var m: Macro
        private val trigger = TextView(this@MacroService)
        private val target = TextView(this@MacroService)
        private val tp = lp(0, 0)
        private val gp = lp(0, 0)
        private var firing = false
        private var edit = false
        private var sz = Point(1, 1)
        private val rnd = java.util.Random()

        private val loop = object : Runnable {
            override fun run() {
                if (!firing) return
                tap()
                h.postDelayed(this, (1000L / m.cps).coerceAtLeast(20L))
            }
        }

        private val dragT = DragScale(this@MacroService,
            { dx, dy -> shift(0, dx, dy) },
            { f -> m.triggerDp = (m.triggerDp * f).coerceIn(40f, 220f); relayout() },
            { Store.save(this@MacroService, macros) })
        private val dragG = DragScale(this@MacroService,
            { dx, dy -> shift(2, dx, dy) },
            { f -> m.targetDp = (m.targetDp * f).coerceIn(30f, 300f); relayout() },
            { Store.save(this@MacroService, macros) })

        init {
            trigger.setOnTouchListener { v, e -> if (edit) dragT.onTouch(v, e) else press(e) }
            target.setOnTouchListener { v, e -> if (edit) dragG.onTouch(v, e) else false }
        }

        private fun press(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> if (m.toggleMode && firing) stop() else start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (!m.toggleMode) stop()
            }
            return true
        }

        fun update(macro: Macro, show: Boolean, editMode: Boolean, size: Point) {
            m = macro; edit = editMode; sz = size
            if (!show) { stop(); detach(trigger); detach(target); return }
            if (edit) stop()
            style(); relayout()
        }

        private fun start() {
            if (firing) return
            firing = true; style(); h.post(loop)
        }

        fun stop() {
            firing = false
            h.removeCallbacks(loop)
            if (::m.isInitialized) style()
        }

        fun destroy() {
            stop(); detach(trigger); detach(target)
        }

        private fun shift(k: Int, dx: Float, dy: Float) {
            val b = (if (sz.x >= sz.y) 0 else 4) + k
            m.pos[b] = (m.pos[b] + dx / sz.x).coerceIn(0f, 1f)
            m.pos[b + 1] = (m.pos[b + 1] + dy / sz.y).coerceIn(0f, 1f)
            relayout()
        }

        private fun relayout() {
            place(trigger, tp, 0, m.triggerDp, false)
            place(target, gp, 2, m.targetDp, true)
        }

        @Suppress("DEPRECATION")
        private fun place(v: View, p: WindowManager.LayoutParams, k: Int, size: Float, isTarget: Boolean) {
            val px = dpf(size)
            val b = (if (sz.x >= sz.y) 0 else 4) + k
            p.width = px; p.height = px
            p.x = (m.pos[b] * sz.x - px / 2f).toInt()
            p.y = (m.pos[b + 1] * sz.y - px / 2f).toInt()
            val nt = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            // Hedef halka dokunmaya kapalı: böylece gönderilen tıklamalar altındaki oyuna geçer
            p.flags = if (isTarget && !edit) p.flags or nt else p.flags and nt.inv()
            if (v.parent == null) wm.addView(v, p) else wm.updateViewLayout(v, p)
        }

        private fun style() {
            val col = Color.parseColor(
                when {
                    edit -> "#F59E0B"
                    firing -> "#22C55E"
                    else -> "#3B82F6"
                }
            )
            trigger.apply {
                text = if (edit) "${m.name}\ntuş" else m.name
                gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 12f
                setTypeface(null, Typeface.BOLD)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(col); setStroke(dp(2), Color.WHITE)
                }
                alpha = if (edit) 0.95f else m.opacity
            }
            target.apply {
                text = if (edit) "${m.name}\nhedef" else ""
                gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 11f
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(if (edit) "#3322D3EE" else "#00000000"))
                    setStroke(dp(2), Color.parseColor("#22D3EE"), dp(6).toFloat(), dp(4).toFloat())
                }
                alpha = if (edit) 0.95f else (m.opacity * 0.8f)
            }
        }

        private fun tap() {
            val r = target.width / 2f
            if (r <= 0f) return
            val loc = IntArray(2)
            target.getLocationOnScreen(loc)
            val ang = rnd.nextDouble() * 2 * Math.PI
            val d = sqrt(rnd.nextDouble()) * r * 0.85
            val x = loc[0] + r + (cos(ang) * d).toFloat()
            val y = loc[1] + r + (sin(ang) * d).toFloat()
            val path = Path().apply { moveTo(x, y) }
            val dur = (1000L / m.cps - 10L).coerceIn(1L, 20L)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
            dispatchGesture(g, null, null)
        }
    }
}
